import type { Metadata } from "next";
import { Playfair_Display, Lato } from "next/font/google";
import "./globals.css";

const playfair = Playfair_Display({
  variable: "--font-playfair",
  subsets: ["latin"],
  display: "swap",
});

const lato = Lato({
  variable: "--font-lato",
  subsets: ["latin"],
  weight: ["300", "400", "700"],
  display: "swap",
});

export const metadata: Metadata = {
  title: "Blue Olives Taverna | A Santorini-Inspired Culinary Escape",
  description:
    "Nestled within Little MyKonos Hotel, Blue Olives Taverna invites you to an exquisite Mediterranean dining experience. Inspired by the sun-drenched shores of Santorini, every detail is crafted to transport you across the Aegean Sea.",
  keywords: [
    "Blue Olives Taverna",
    "Mediterranean restaurant Bandung",
    "Santorini Bandung",
    "Little MyKonos Hotel",
    "fine dining Bandung",
    "Mediterranean cuisine",
    "Bandung restaurant",
    "private dining Bandung",
    "romantic restaurant Bandung",
  ],
  authors: [{ name: "Blue Olives Taverna" }],
  icons: {
    icon: "https://cdn-icons-png.flaticon.com/512/2917/2917997.png",
  },
  openGraph: {
    title: "Blue Olives Taverna | A Santorini-Inspired Culinary Escape",
    description:
      "Where the Aegean breeze meets Bandung's highlands. An exquisite Mediterranean dining experience at Little MyKonos Hotel.",
    siteName: "Blue Olives Taverna",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Blue Olives Taverna | A Santorini-Inspired Culinary Escape",
    description:
      "Where the Aegean breeze meets Bandung's highlands. An exquisite Mediterranean dining experience.",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="id" suppressHydrationWarning>
      <body
        className={`${playfair.variable} ${lato.variable} antialiased bg-cream text-foreground`}
      >
        {children}
      </body>
    </html>
  );
}
