'use client'

import { useState, useCallback, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  MapPin, Clock, Phone, Camera, ChevronDown,
  Star, Calendar, Users, Heart, Wine, Sparkles,
  X, ArrowRight, Quote, MessageCircle
} from 'lucide-react'

/* ============================================================
   🫒 BLUE OLIVES TAVERNA — HIGH-END RESTAURANT WEBSITE
   
   Sebuah website restoran fine dining yang menampilkan
   keindahan dan kemewahan Blue Olives Taverna tanpa
   menampilkan menu maupun sistem pemesanan.
   
   CARA GANTI GAMBAR:
   Ubah path di bagian RESTAURANT_IMAGES atau GALLERY_ITEMS.
   Simpan gambar Anda di folder: /public/images/
   Contoh: "/images/foto-anda.jpg"
   ============================================================ */

// Restaurant Data — sesuai data Google Maps yang terkonfirmasi
const RESTAURANT = {
  name: 'Blue Olives Taverna',
  subtitle: 'A Santorini-Inspired Culinary Escape',
  address: 'Jl. Kebon Sirih No.31, Babakan Ciamis, Kec. Sumur Bandung, Kota Bandung 40117',
  shortAddress: 'GF Lobby, Little MyKonos Hotel',
  phone: '+6287888972231',
  whatsapp: '6287888972231',
  instagram: 'blueolives_taverna',
  instagramUrl: 'https://instagram.com/blueolives_taverna',
  hours: 'Setiap Hari, 07.00 – 22.00',
  mapsUrl: 'https://maps.app.goo.gl/2MTMoRkufbn5UWWB8',
  rating: 5.0,
  reviews: 51,
  founded: '2021',
  cuisine: 'Mediterranean & Indonesian Fusion',
  capacity: '80 seats',
  privateDining: 'Ruang privat hingga 30 tamu',
}

/* ============================================================
   CARA GANTI GAMBAR:
   Ubah path di properti "src" pada array di bawah.
   Simpan gambar Anda di folder: /public/images/venue/
   Contoh: src: "/images/venue/foto-anda.jpg"
   ============================================================ */
const GALLERY_ITEMS = [
  { src: '/images/venue/exterior.png', alt: 'Fasad Blue Olives Taverna bergaya Santorini', label: 'Eksterior', span: 'md:col-span-2 md:row-span-2' },
  { src: '/images/venue/interior.png', alt: 'Interior elegan Blue Olives Taverna', label: 'Interior', span: '' },
  { src: '/images/venue/ambience.png', alt: 'Suasana outdoor terrace Blue Olives', label: 'Terrace', span: '' },
]

// Testimonial data — reviews from confirmed visitors
const TESTIMONIALS = [
  {
    name: 'Amelia R.',
    location: 'Jakarta',
    text: 'Begitu masuk, seakan kita dibawa langsung ke Santorini. Setiap detail interiornya dipikirkan dengan sangat baik — dari dinding putih biru hingga pencahayaan golden hour yang menembus kaca. Pengalaman bersantap yang sungguh tak terlupakan.',
    rating: 5,
  },
  {
    name: 'David H.',
    location: 'Bandung',
    text: 'Tempat sempurna untuk perayaan spesial. Tim mereka sangat perhatian dan memastikan setiap detail berjalan lancar. Suasana privat namun tetap hangat — sulit menemukan tempat sekelas ini di Bandung.',
    rating: 5,
  },
  {
    name: 'Sari K.',
    location: 'Surabaya',
    text: 'Sudah tiga kali berkunjung dan selalu ada hal baru yang membuat kami terpesona. Kualitas dan konsistensi mereka luar biasa. Ini bukan sekadar restoran — ini adalah sebuah destinasi.',
    rating: 5,
  },
  {
    name: 'Marco T.',
    location: 'Bali',
    text: 'Sebagai seseorang yang sering bepergian ke Mediterania, saya kagum dengan autentisitas yang ditangkap Blue Olives. Atmosfernya genuine, pelayanannya world-class. Bandung beruntung memiliki tempat ini.',
    rating: 5,
  },
]

// Elegant animation variants
const fadeInUp = {
  hidden: { opacity: 0, y: 40 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.8, ease: [0.25, 0.46, 0.45, 0.94] } },
}

const staggerContainer = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.15, delayChildren: 0.1 },
  },
}

const staggerItem = {
  hidden: { opacity: 0, y: 30 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6, ease: 'easeOut' } },
}

/* ============================================================
   SUB-COMPONENTS (semua dalam 1 file)
   ============================================================ */

// --- Decorative Gold Line ---
function GoldLine({ className = '' }: { className?: string }) {
  return (
    <div className={`flex items-center justify-center gap-3 ${className}`}>
      <div className="h-px w-12 bg-gradient-to-r from-transparent to-gold" />
      <Sparkles className="w-4 h-4 text-gold" />
      <div className="h-px w-12 bg-gradient-to-l from-transparent to-gold" />
    </div>
  )
}

// --- Navigation Bar ---
function Navbar() {
  const [scrolled, setScrolled] = useState(false)
  const [mobileOpen, setMobileOpen] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 60)
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  const navLinks = [
    { label: 'Cerita Kami', href: '#about' },
    { label: 'Suasana', href: '#ambiance' },
    { label: 'Chef', href: '#chef' },
    { label: 'Acara', href: '#events' },
    { label: 'Reservasi', href: '#reservation' },
    { label: 'Kontak', href: '#contact' },
  ]

  return (
    <motion.nav
      initial={{ y: -80 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.8, ease: 'easeOut' }}
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-700 ${
        scrolled
          ? 'bg-white/95 backdrop-blur-xl shadow-lg shadow-olive/5'
          : 'bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 md:h-20">
          {/* Logo */}
          <a href="#" className="flex items-center gap-2.5 group">
            <span className="text-2xl">🫒</span>
            <div className="flex flex-col">
              <span className={`font-bold text-lg leading-tight tracking-wide transition-colors duration-500 ${
                scrolled ? 'text-olive-dark' : 'text-white'
              }`} style={{ fontFamily: 'var(--font-playfair), Georgia, serif' }}>
                Blue Olives
              </span>
              <span className={`text-[9px] tracking-[0.3em] uppercase leading-tight transition-colors duration-500 ${
                scrolled ? 'text-olive' : 'text-sand'
              }`}>
                Taverna
              </span>
            </div>
          </a>

          {/* Desktop Nav */}
          <div className="hidden lg:flex items-center gap-7">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className={`text-[13px] font-medium tracking-wide transition-colors duration-300 hover:text-olive ${
                  scrolled ? 'text-foreground/80' : 'text-white/80'
                }`}
              >
                {link.label}
              </a>
            ))}
            <a
              href="#reservation"
              className="bg-olive hover:bg-olive-dark text-white px-6 py-2.5 rounded-full text-[13px] font-semibold tracking-wide transition-all duration-300 hover:shadow-lg hover:shadow-olive/30 hover:-translate-y-0.5"
            >
              Reservasi
            </a>
          </div>

          {/* Mobile Toggle */}
          <button
            onClick={() => setMobileOpen(!mobileOpen)}
            className="lg:hidden p-2"
            aria-label="Menu navigasi"
          >
            <div className="space-y-1.5">
              <span className={`block w-6 h-[1.5px] transition-all duration-300 ${
                scrolled ? 'bg-olive-dark' : 'bg-white'
              } ${mobileOpen ? 'rotate-45 translate-y-[7px]' : ''}`} />
              <span className={`block w-6 h-[1.5px] transition-all duration-300 ${
                scrolled ? 'bg-olive-dark' : 'bg-white'
              } ${mobileOpen ? 'opacity-0' : ''}`} />
              <span className={`block w-6 h-[1.5px] transition-all duration-300 ${
                scrolled ? 'bg-olive-dark' : 'bg-white'
              } ${mobileOpen ? '-rotate-45 -translate-y-[7px]' : ''}`} />
            </div>
          </button>
        </div>
      </div>

      {/* Mobile Nav */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="lg:hidden bg-white/98 backdrop-blur-xl border-t border-sand overflow-hidden"
          >
            <div className="px-4 py-4 space-y-0.5">
              {navLinks.map((link) => (
                <a
                  key={link.href}
                  href={link.href}
                  onClick={() => setMobileOpen(false)}
                  className="block py-3 px-4 rounded-xl text-foreground font-medium hover:bg-olive/5 transition-colors tracking-wide"
                >
                  {link.label}
                </a>
              ))}
              <a
                href="#reservation"
                onClick={() => setMobileOpen(false)}
                className="block text-center bg-olive text-white py-3.5 rounded-xl font-semibold mt-3 tracking-wide"
              >
                Reservasi
              </a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.nav>
  )
}

// --- Hero Section ---
function HeroSection() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Animated Gradient Background */}
      <div
        className="absolute inset-0 animate-gradient-dance"
        style={{
          background: `linear-gradient(135deg, 
            #0D4E8B 0%, 
            #1E6FAF 15%, 
            #3A8FD4 30%,
            #5BA3D9 40%,
            #6B8E23 55%, 
            #4A6B0F 70%, 
            #2C4A12 85%, 
            #0D4E8B 100%
          )`,
          backgroundSize: '300% 300%',
        }}
      />

      {/* Elegant floating decorative elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <motion.div
          animate={{ y: [-8, 8, -8], rotate: [0, 3, 0] }}
          transition={{ duration: 8, repeat: Infinity, ease: 'easeInOut' }}
          className="absolute top-[12%] left-[8%] w-24 h-24 md:w-36 md:h-36 rounded-full bg-white/5 blur-xl"
        />
        <motion.div
          animate={{ y: [6, -10, 6], rotate: [0, -2, 0] }}
          transition={{ duration: 10, repeat: Infinity, ease: 'easeInOut', delay: 2 }}
          className="absolute top-[20%] right-[10%] w-32 h-32 md:w-48 md:h-48 rounded-full bg-gold/10 blur-2xl"
        />
        <motion.div
          animate={{ y: [-5, 12, -5] }}
          transition={{ duration: 7, repeat: Infinity, ease: 'easeInOut', delay: 1 }}
          className="absolute bottom-[15%] left-[20%] w-28 h-28 md:w-40 md:h-40 rounded-full bg-santorini-light/10 blur-xl"
        />
        <motion.div
          animate={{ y: [10, -8, 10], rotate: [0, 2, 0] }}
          transition={{ duration: 9, repeat: Infinity, ease: 'easeInOut', delay: 3 }}
          className="absolute bottom-[25%] right-[15%] w-20 h-20 md:w-32 md:h-32 rounded-full bg-white/5 blur-xl"
        />
      </div>

      {/* Subtle grain texture overlay */}
      <div className="absolute inset-0 opacity-[0.03]" style={{
        backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)' opacity='1'/%3E%3C/svg%3E")`,
      }} />

      {/* Overlay for readability */}
      <div className="absolute inset-0 bg-gradient-to-b from-black/30 via-black/10 to-black/40" />

      {/* Content */}
      <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.3 }}
        >
          <span className="inline-block text-sand/80 text-xs md:text-sm tracking-[0.4em] uppercase font-light mb-6">
            ✦ Little MyKonos Hotel, Bandung ✦
          </span>
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.5 }}
          className="text-5xl md:text-7xl lg:text-8xl font-bold text-white mb-4 leading-[0.95]"
          style={{ fontFamily: 'var(--font-playfair), Georgia, serif' }}
        >
          Blue Olives
          <br />
          <span className="text-sand/90 font-light italic">Taverna</span>
        </motion.h1>

        <motion.div
          initial={{ opacity: 0, scaleX: 0 }}
          animate={{ opacity: 1, scaleX: 1 }}
          transition={{ duration: 1, delay: 0.9 }}
          className="flex items-center justify-center gap-3 my-6"
        >
          <div className="h-px w-16 bg-gradient-to-r from-transparent to-gold/60" />
          <span className="text-gold/80 text-lg">✦</span>
          <div className="h-px w-16 bg-gradient-to-l from-transparent to-gold/60" />
        </motion.div>

        <motion.p
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.8 }}
          className="text-base md:text-lg text-white/75 max-w-xl mx-auto mb-10 leading-relaxed font-light tracking-wide"
          style={{ fontFamily: 'var(--font-lato), sans-serif' }}
        >
          Where the Aegean breeze meets Bandung&apos;s highlands.
          <br className="hidden sm:block" />
          An exquisite Mediterranean escape awaits.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 1.1 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-4"
        >
          <a
            href="#reservation"
            className="group bg-white text-olive-dark px-8 py-4 rounded-full font-semibold text-sm tracking-wider transition-all duration-300 hover:bg-sand hover:shadow-2xl hover:shadow-white/10 hover:-translate-y-1 flex items-center gap-2"
          >
            Reservasi
            <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
          </a>
          <a
            href={RESTAURANT.mapsUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="border border-white/30 text-white/90 px-8 py-4 rounded-full font-medium text-sm tracking-wider transition-all duration-300 hover:bg-white/10 hover:border-white/50 hover:-translate-y-1 flex items-center gap-2"
          >
            <MapPin className="w-4 h-4" />
            Petunjuk Arah
          </a>
        </motion.div>

        {/* Rating badge */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.5 }}
          className="mt-12 inline-flex items-center gap-2.5 bg-white/10 backdrop-blur-sm px-5 py-2.5 rounded-full border border-white/10"
        >
          <div className="flex gap-0.5">
            {[...Array(5)].map((_, i) => (
              <Star key={i} className="w-3.5 h-3.5 fill-gold text-gold" />
            ))}
          </div>
          <span className="text-white/80 text-sm font-light tracking-wide">
            {RESTAURANT.rating} · {RESTAURANT.reviews} ulasan
          </span>
        </motion.div>
      </div>

      {/* Scroll indicator */}
      <motion.div
        animate={{ y: [0, 10, 0] }}
        transition={{ duration: 2.5, repeat: Infinity, ease: 'easeInOut' }}
        className="absolute bottom-10 left-1/2 -translate-x-1/2"
      >
        <div className="flex flex-col items-center gap-2">
          <span className="text-white/40 text-[10px] tracking-[0.3em] uppercase">Scroll</span>
          <ChevronDown className="w-5 h-5 text-white/40" />
        </div>
      </motion.div>
    </section>
  )
}

// --- About / Our Story Section ---
function AboutSection() {
  return (
    <section id="about" className="py-24 md:py-32 bg-cream">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          {/* Image */}
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-80px' }}
            transition={{ duration: 0.8 }}
            className="relative"
          >
            <div className="relative rounded-3xl overflow-hidden shadow-2xl shadow-olive/10">
              {/* CARA GANTI GAMBAR: Ubah src di bawah */}
              <img
                src="/images/venue/interior.png"
                alt="Interior Blue Olives Taverna"
                className="w-full h-[400px] md:h-[520px] object-cover"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent" />
            </div>
            {/* Decorative floating card */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.4 }}
              className="absolute -bottom-6 -right-4 md:-right-8 bg-white rounded-2xl p-5 shadow-xl shadow-olive/10 border border-sand"
            >
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-olive/10 rounded-xl flex items-center justify-center">
                  <Wine className="w-6 h-6 text-olive" />
                </div>
                <div>
                  <span className="font-bold text-foreground text-lg" style={{ fontFamily: 'var(--font-playfair), serif' }}>
                    {RESTAURANT.founded}
                  </span>
                  <p className="text-muted-foreground text-xs">Sejak tahun</p>
                </div>
              </div>
            </motion.div>
          </motion.div>

          {/* Content */}
          <motion.div
            initial={{ opacity: 0, x: 40 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-80px' }}
            transition={{ duration: 0.8 }}
          >
            <span className="text-olive text-xs tracking-[0.3em] uppercase font-semibold">
              Cerita Kami
            </span>
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mt-3 mb-6 leading-tight" style={{ fontFamily: 'var(--font-playfair), Georgia, serif' }}>
              Sebuah Kisah dari<br />
              <span className="text-olive italic">Pantai Aegea</span>
            </h2>
            <GoldLine className="mb-6 justify-start" />
            <div className="space-y-4 text-muted-foreground leading-relaxed" style={{ fontFamily: 'var(--font-lato), sans-serif' }}>
              <p>
                Blue Olives Taverna lahir dari sebuah impian sederhana — membawa keajaiban Santorini ke jantung kota Bandung. Terletak di lantai dasar Little MyKonos Hotel, setiap inci ruangan kami dirancang untuk mengangkut Anda melintasi lautan Aegea, ke desa-desa putih yang bertengger di tebing dengan pemandangan matahari terbenam yang legendaris.
              </p>
              <p>
                Dinding putih bersih yang bertemu dengan nuansa biru Santorini, pohon zaitun yang rindang, dan pencahayaan yang dirancang untuk menangkap golden hour — semua ini bukan kebetulan. Ini adalah hasil dari perjalanan panjang dan dedikasi untuk menciptakan pengalaman bersantap yang melampaui sekadar hidangan di piring.
              </p>
              <p>
                Kami percaya bahwa makanan terbaik disajikan dalam suasana yang terbaik. Di Blue Olives Taverna, setiap kunjungan adalah sebuah perjalanan — sebuah pelarian sejenak dari rutinitas, menuju tempat di mana waktu berjalan lebih lambat dan setiap momen layak diabadikan.
              </p>
            </div>

            {/* Key highlights */}
            <div className="grid grid-cols-2 gap-4 mt-8">
              {[
                { label: 'Kapasitas', value: RESTAURANT.capacity, icon: Users },
                { label: 'Ruang Privat', value: RESTAURANT.privateDining, icon: Heart },
                { label: 'Jam Operasional', value: '15 Jam/Hari', icon: Clock },
                { label: 'Rating', value: `${RESTAURANT.rating} / 5.0`, icon: Star },
              ].map(({ label, value, icon: Icon }) => (
                <div key={label} className="bg-white rounded-xl p-4 border border-sand">
                  <Icon className="w-4 h-4 text-olive mb-2" />
                  <span className="text-xs text-muted-foreground block">{label}</span>
                  <span className="font-semibold text-foreground text-sm">{value}</span>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}

// --- Ambiance / Gallery Section ---
function AmbianceSection() {
  const [lightboxImg, setLightboxImg] = useState<string | null>(null)

  return (
    <section id="ambiance" className="py-24 md:py-32 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={fadeInUp.hidden}
          whileInView={fadeInUp.visible}
          viewport={{ once: true, margin: '-80px' }}
          className="text-center mb-14"
        >
          <span className="text-olive text-xs tracking-[0.3em] uppercase font-semibold">
            Suasana
          </span>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mt-3 mb-4" style={{ fontFamily: 'var(--font-playfair), Georgia, serif' }}>
            Rasakan Keindahan Santorini
          </h2>
          <GoldLine className="mb-4" />
          <p className="text-muted-foreground max-w-2xl mx-auto text-sm md:text-base leading-relaxed" style={{ fontFamily: 'var(--font-lato), sans-serif' }}>
            Setiap sudut Blue Olives Taverna dirancang untuk memanjakan mata dan menenangkan jiwa.
            Interior putih-biru khas Santorini, olive trees yang rindang, dan cahaya golden hour
            yang menembus kaca — sebuah mahakarya arsitektur di jantung Bandung.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-5">
          {GALLERY_ITEMS.map((img, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.15, duration: 0.6 }}
              className={`relative group rounded-2xl overflow-hidden cursor-zoom-in ${img.span}`}
              onClick={() => setLightboxImg(img.src)}
            >
              <img
                src={img.src}
                alt={img.alt}
                className="w-full h-64 md:h-full object-cover transition-transform duration-700 group-hover:scale-105"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/10 to-transparent opacity-60 group-hover:opacity-80 transition-opacity duration-500" />
              <div className="absolute bottom-4 left-4 right-4 flex items-end justify-between">
                <span className="text-white font-medium text-sm tracking-wide">
                  {img.label}
                </span>
                <span className="text-white/50 text-[10px] tracking-widest uppercase">
                  Klik untuk perbesar
                </span>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Lightbox */}
        <AnimatePresence>
          {lightboxImg && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="lightbox-overlay"
              onClick={() => setLightboxImg(null)}
            >
              <motion.img
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.9, opacity: 0 }}
                transition={{ duration: 0.3 }}
                src={lightboxImg}
                alt="Gallery"
                className="max-w-[90vw] max-h-[85vh] object-contain rounded-lg"
                onClick={(e) => e.stopPropagation()}
              />
              <button
                onClick={() => setLightboxImg(null)}
                className="absolute top-6 right-6 text-white/70 hover:text-white transition-colors p-2"
                aria-label="Tutup gambar"
              >
                <X className="w-8 h-8" />
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </section>
  )
}

// --- Chef Section ---
function ChefSection() {
  return (
    <section id="chef" className="py-24 md:py-32 bg-cream relative overflow-hidden">
      {/* Decorative background elements */}
      <div className="absolute top-0 right-0 w-72 h-72 bg-olive/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/3" />
      <div className="absolute bottom-0 left-0 w-56 h-56 bg-santorini/5 rounded-full blur-3xl translate-y-1/2 -translate-x-1/3" />

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <motion.div
          initial={fadeInUp.hidden}
          whileInView={fadeInUp.visible}
          viewport={{ once: true, margin: '-80px' }}
          className="text-center mb-14"
        >
          <span className="text-olive text-xs tracking-[0.3em] uppercase font-semibold">
            Maestro Dapur
          </span>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mt-3 mb-4" style={{ fontFamily: 'var(--font-playfair), Georgia, serif' }}>
            The Culinary Artist
          </h2>
          <GoldLine className="mb-4" />
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-5 gap-10 lg:gap-16 items-center">
          {/* Chef Image */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="lg:col-span-2"
          >
            <div className="relative">
              {/* CARA GANTI GAMBAR: Ubah src di bawah ke foto chef Anda */}
              <img
                src="/images/venue/ambience.png"
                alt="Chef Blue Olives Taverna"
                className="w-full h-[350px] md:h-[450px] object-cover rounded-3xl shadow-xl shadow-olive/10"
                loading="lazy"
              />
              {/* Decorative border */}
              <div className="absolute inset-0 rounded-3xl border-2 border-gold/20 pointer-events-none" />
              <div className="absolute -bottom-4 -left-4 w-24 h-24 border-2 border-gold/30 rounded-2xl" />
            </div>
          </motion.div>

          {/* Chef Content */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="lg:col-span-3"
          >
            <Quote className="w-10 h-10 text-olive/20 mb-4" />
            <p className="text-foreground/80 text-base md:text-lg leading-relaxed mb-6 italic" style={{ fontFamily: 'var(--font-playfair), Georgia, serif' }}>
              &ldquo;Memasak adalah bahasa universal yang melampaui batas negara. Di Blue Olives, kami bercerita melalui setiap hidangan — merangkai rempah Nusantara dengan teknik Mediterania, menciptakan harmoni rasa yang tak terduga namun terasa seperti pulang ke rumah.&rdquo;
            </p>
            <div className="flex items-center gap-4">
              <div className="h-px flex-1 bg-gradient-to-r from-sand-dark to-transparent" />
              <div className="text-center">
                <span className="font-bold text-foreground block" style={{ fontFamily: 'var(--font-playfair), Georgia, serif' }}>
                  Head Chef
                </span>
                <span className="text-muted-foreground text-sm">Blue Olives Taverna</span>
              </div>
            </div>

            <div className="mt-8 space-y-3">
              <p className="text-muted-foreground leading-relaxed text-sm" style={{ fontFamily: 'var(--font-lato), sans-serif' }}>
                Dengan pengalaman lebih dari satu dekade di dapur-dapur terbaik, chef kami membawa filosofi yang sederhana namun mendalam: setiap bahan punya cerita, dan tugas seorang chef adalah menyampaikan cerita itu dengan jujur dan penuh hormat.
              </p>
              <p className="text-muted-foreground leading-relaxed text-sm" style={{ fontFamily: 'var(--font-lato), sans-serif' }}>
                Di Blue Olives Taverna, dapur bukan sekadar tempat memasak — ia adalah panggung di mana tradisi bertemu inovasi, di mana rempah-rempah lokal berdialog dengan teknik kuliner Mediterania, menghasilkan pengalaman gastronomi yang autentik namun segar.
              </p>
            </div>

            <div className="flex items-center gap-6 mt-8">
              <div className="flex items-center gap-2 text-olive">
                <Wine className="w-5 h-5" />
                <span className="text-sm font-medium">{RESTAURANT.cuisine}</span>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}

// --- Private Dining & Events Section ---
function EventsSection() {
  const events = [
    {
      icon: Heart,
      title: 'Romantic Dinner',
      description: 'Sebuah malam romantis di bawah cahaya lilin dengan pemandangan yang menawan. Sempurna untuk anniversary, lamaran, atau sekadar merayakan cinta. Tim kami akan memastikan setiap detail — dari dekorasi meja hingga musik latar — menjadi bagian dari kenangan tak terlupakan Anda berdua.',
    },
    {
      icon: Users,
      title: 'Private Gathering',
      description: 'Ruang privat kami yang elegan dapat menampung hingga 30 tamu, ideal untuk perayaan ulang tahun, reuni keluarga, atau pertemuan bisnis yang memerlukan sentuhan eksklusif. Dengan layanan personal dan suasana yang intim, acara Anda akan terasa begitu istimewa.',
    },
    {
      icon: Calendar,
      title: 'Corporate Events',
      description: 'Angkat standar acara perusahaan Anda ke level berikutnya. Baik dinner meeting, peluncuran produk, atau gathering tahunan — Blue Olives menyediakan latar yang sophisticated dan layanan impeccable yang akan memukau setiap tamu undangan Anda.',
    },
  ]

  return (
    <section id="events" className="py-24 md:py-32 bg-white">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={fadeInUp.hidden}
          whileInView={fadeInUp.visible}
          viewport={{ once: true, margin: '-80px' }}
          className="text-center mb-14"
        >
          <span className="text-olive text-xs tracking-[0.3em] uppercase font-semibold">
            Acara & Perayaan
          </span>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mt-3 mb-4" style={{ fontFamily: 'var(--font-playfair), Georgia, serif' }}>
            Momen Spesial Anda,<br />
            <span className="text-olive italic">Panggung Kami</span>
          </h2>
          <GoldLine className="mb-4" />
          <p className="text-muted-foreground max-w-2xl mx-auto text-sm md:text-base leading-relaxed" style={{ fontFamily: 'var(--font-lato), sans-serif' }}>
            Setiap perayaan layak memiliki latar yang setara. Di Blue Olives Taverna,
            kami menyediakan lebih dari sekadar ruangan — kami menyediakan pengalaman.
          </p>
        </motion.div>

        <motion.div
          variants={staggerContainer}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: '-60px' }}
          className="grid grid-cols-1 md:grid-cols-3 gap-6"
        >
          {events.map((event, i) => {
            const Icon = event.icon
            return (
              <motion.div
                key={i}
                variants={staggerItem}
                className="group bg-cream rounded-2xl p-8 border border-sand hover:border-olive/20 transition-all duration-500 hover:shadow-xl hover:shadow-olive/5 hover:-translate-y-1"
              >
                <div className="w-14 h-14 bg-olive/10 rounded-2xl flex items-center justify-center mb-5 group-hover:bg-olive/20 transition-colors duration-300">
                  <Icon className="w-7 h-7 text-olive" />
                </div>
                <h3 className="text-xl font-bold text-foreground mb-3" style={{ fontFamily: 'var(--font-playfair), Georgia, serif' }}>
                  {event.title}
                </h3>
                <p className="text-muted-foreground text-sm leading-relaxed" style={{ fontFamily: 'var(--font-lato), sans-serif' }}>
                  {event.description}
                </p>
              </motion.div>
            )
          })}
        </motion.div>

        {/* CTA for events */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.3 }}
          className="text-center mt-12"
        >
          <a
            href={`https://wa.me/${RESTAURANT.whatsapp}?text=${encodeURIComponent('🫒 Halo Blue Olives Taverna,\n\nSaya tertarik untuk menyelenggarakan acara di tempat Anda. Bisakah kami mendiskusikan lebih lanjut?\n\nTerima kasih.')}`}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 bg-olive hover:bg-olive-dark text-white px-8 py-4 rounded-full font-semibold text-sm tracking-wide transition-all duration-300 hover:shadow-lg hover:shadow-olive/30 hover:-translate-y-0.5"
          >
            <MessageCircle className="w-4 h-4" />
            Konsultasi Acara via WhatsApp
          </a>
        </motion.div>
      </div>
    </section>
  )
}

// --- Testimonials Section ---
function TestimonialsSection() {
  return (
    <section className="py-24 md:py-32 bg-cream relative overflow-hidden">
      {/* Decorative background */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-20 left-10 text-[200px] leading-none text-olive" style={{ fontFamily: 'var(--font-playfair), Georgia, serif' }}>✦</div>
        <div className="absolute bottom-20 right-10 text-[150px] leading-none text-olive" style={{ fontFamily: 'var(--font-playfair), Georgia, serif' }}>✦</div>
      </div>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <motion.div
          initial={fadeInUp.hidden}
          whileInView={fadeInUp.visible}
          viewport={{ once: true, margin: '-80px' }}
          className="text-center mb-14"
        >
          <span className="text-olive text-xs tracking-[0.3em] uppercase font-semibold">
            Kata Mereka
          </span>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mt-3 mb-4" style={{ fontFamily: 'var(--font-playfair), Georgia, serif' }}>
            Suara dari Tamu Kami
          </h2>
          <GoldLine className="mb-4" />
        </motion.div>

        <motion.div
          variants={staggerContainer}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: '-60px' }}
          className="grid grid-cols-1 md:grid-cols-2 gap-6"
        >
          {TESTIMONIALS.map((t, i) => (
            <motion.div
              key={i}
              variants={staggerItem}
              className="bg-white rounded-2xl p-7 border border-sand hover:border-olive/15 transition-all duration-300 hover:shadow-lg hover:shadow-olive/5"
            >
              <div className="flex gap-0.5 mb-4">
                {[...Array(t.rating)].map((_, j) => (
                  <Star key={j} className="w-4 h-4 fill-gold text-gold" />
                ))}
              </div>
              <p className="text-foreground/80 text-sm leading-relaxed mb-5" style={{ fontFamily: 'var(--font-lato), sans-serif' }}>
                &ldquo;{t.text}&rdquo;
              </p>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-olive/10 rounded-full flex items-center justify-center">
                  <span className="text-olive font-bold text-sm">{t.name.charAt(0)}</span>
                </div>
                <div>
                  <span className="font-semibold text-foreground text-sm block">{t.name}</span>
                  <span className="text-muted-foreground text-xs">{t.location}</span>
                </div>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  )
}

// --- Reservation Section ---
function ReservationSection() {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    date: '',
    time: '',
    guests: '2',
    notes: '',
  })

  const handleChange = useCallback((field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }, [])

  const buildWhatsAppMessage = useCallback(() => {
    const msg = `🫒 *Reservasi Blue Olives Taverna*\n\n` +
      `👤 Nama: ${formData.name}\n` +
      `📱 Telepon: ${formData.phone}\n` +
      `📅 Tanggal: ${formData.date}\n` +
      `🕐 Waktu: ${formData.time}\n` +
      `👥 Jumlah Tamu: ${formData.guests} orang\n` +
      `📝 Catatan: ${formData.notes || '-'}\n\n` +
      `Terima kasih, kami menantikan kedatangan Anda.`
    return encodeURIComponent(msg)
  }, [formData])

  const handleSubmit = useCallback((e: React.FormEvent) => {
    e.preventDefault()
    const url = `https://wa.me/${RESTAURANT.whatsapp}?text=${buildWhatsAppMessage()}`
    window.open(url, '_blank')
  }, [buildWhatsAppMessage])

  return (
    <section id="reservation" className="py-24 md:py-32 bg-white relative overflow-hidden">
      {/* Decorative background */}
      <div className="absolute top-0 left-0 w-80 h-80 bg-santorini/5 rounded-full blur-3xl -translate-x-1/2 -translate-y-1/2" />
      <div className="absolute bottom-0 right-0 w-64 h-64 bg-olive/5 rounded-full blur-3xl translate-x-1/2 translate-y-1/2" />

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <motion.div
          initial={fadeInUp.hidden}
          whileInView={fadeInUp.visible}
          viewport={{ once: true, margin: '-80px' }}
          className="text-center mb-14"
        >
          <span className="text-olive text-xs tracking-[0.3em] uppercase font-semibold">
            Reservasi
          </span>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mt-3 mb-4" style={{ fontFamily: 'var(--font-playfair), Georgia, serif' }}>
            Siap untuk Pengalaman<br />
            <span className="text-olive italic">Yang Tak Terlupakan?</span>
          </h2>
          <GoldLine className="mb-4" />
          <p className="text-muted-foreground max-w-xl mx-auto text-sm md:text-base leading-relaxed" style={{ fontFamily: 'var(--font-lato), sans-serif' }}>
            Pesan meja Anda dan biarkan kami mempersiapkan segalanya.
            Setiap reservasi adalah awal dari sebuah cerita yang indah.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="bg-cream rounded-3xl p-6 md:p-10 border border-sand shadow-lg shadow-olive/5 max-w-2xl mx-auto"
        >
          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              <div>
                <label className="block text-xs font-semibold text-foreground mb-2 tracking-wide">
                  Nama Lengkap
                </label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => handleChange('name', e.target.value)}
                  placeholder="Nama Anda"
                  className="w-full bg-white border border-sand rounded-xl px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground/60 focus:outline-none focus:border-olive focus:ring-1 focus:ring-olive/20 transition-all"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-foreground mb-2 tracking-wide">
                  Nomor Telepon
                </label>
                <input
                  type="tel"
                  required
                  value={formData.phone}
                  onChange={(e) => handleChange('phone', e.target.value)}
                  placeholder="08xxxxxxxxxx"
                  className="w-full bg-white border border-sand rounded-xl px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground/60 focus:outline-none focus:border-olive focus:ring-1 focus:ring-olive/20 transition-all"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
              <div>
                <label className="block text-xs font-semibold text-foreground mb-2 tracking-wide">
                  Tanggal
                </label>
                <input
                  type="date"
                  required
                  value={formData.date}
                  onChange={(e) => handleChange('date', e.target.value)}
                  className="w-full bg-white border border-sand rounded-xl px-4 py-3 text-sm text-foreground focus:outline-none focus:border-olive focus:ring-1 focus:ring-olive/20 transition-all"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-foreground mb-2 tracking-wide">
                  Waktu
                </label>
                <select
                  required
                  value={formData.time}
                  onChange={(e) => handleChange('time', e.target.value)}
                  className="w-full bg-white border border-sand rounded-xl px-4 py-3 text-sm text-foreground focus:outline-none focus:border-olive focus:ring-1 focus:ring-olive/20 transition-all appearance-none"
                >
                  <option value="">Pilih waktu</option>
                  <option value="07:00">07:00 - Sarapan</option>
                  <option value="10:00">10:00 - Brunch</option>
                  <option value="12:00">12:00 - Makan Siang</option>
                  <option value="15:00">15:00 - Afternoon</option>
                  <option value="17:00">17:00 - Golden Hour</option>
                  <option value="19:00">19:00 - Makan Malam</option>
                  <option value="21:00">21:00 - Late Night</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-semibold text-foreground mb-2 tracking-wide">
                  Jumlah Tamu
                </label>
                <select
                  value={formData.guests}
                  onChange={(e) => handleChange('guests', e.target.value)}
                  className="w-full bg-white border border-sand rounded-xl px-4 py-3 text-sm text-foreground focus:outline-none focus:border-olive focus:ring-1 focus:ring-olive/20 transition-all appearance-none"
                >
                  {[1, 2, 3, 4, 5, 6, 7, 8, 10, 15, 20, 30].map((n) => (
                    <option key={n} value={n}>
                      {n} orang
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-foreground mb-2 tracking-wide">
                Catatan Khusus <span className="text-muted-foreground font-normal">(opsional)</span>
              </label>
              <textarea
                value={formData.notes}
                onChange={(e) => handleChange('notes', e.target.value)}
                placeholder="Perayaan spesial, alergi makanan, permintaan khusus..."
                rows={3}
                className="w-full bg-white border border-sand rounded-xl px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground/60 focus:outline-none focus:border-olive focus:ring-1 focus:ring-olive/20 transition-all resize-none"
              />
            </div>

            <button
              type="submit"
              className="w-full flex items-center justify-center gap-2 bg-olive hover:bg-olive-dark text-white py-4 rounded-xl font-semibold text-sm tracking-wide transition-all duration-300 hover:shadow-lg hover:shadow-olive/30"
            >
              <MessageCircle className="w-5 h-5" />
              Kirim Reservasi via WhatsApp
            </button>

            <p className="text-center text-muted-foreground text-xs">
              Reservasi akan dikirim langsung ke tim kami melalui WhatsApp.
              <br />
              Kami akan mengonfirmasi ketersediaan meja Anda dalam waktu 30 menit.
            </p>
          </form>
        </motion.div>
      </div>
    </section>
  )
}

// --- Location & Contact Section ---
function ContactSection() {
  return (
    <section id="contact" className="py-24 md:py-32 bg-cream">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={fadeInUp.hidden}
          whileInView={fadeInUp.visible}
          viewport={{ once: true, margin: '-80px' }}
          className="text-center mb-14"
        >
          <span className="text-olive text-xs tracking-[0.3em] uppercase font-semibold">
            Kunjungi Kami
          </span>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mt-3 mb-4" style={{ fontFamily: 'var(--font-playfair), Georgia, serif' }}>
            Temukan Blue Olives
          </h2>
          <GoldLine className="mb-4" />
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 max-w-5xl mx-auto">
          {/* Info Cards */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="space-y-4"
          >
            <div className="bg-white rounded-2xl p-6 border border-sand hover:border-olive/20 transition-all duration-300">
              <div className="flex items-start gap-4">
                <div className="w-11 h-11 bg-olive/10 rounded-xl flex items-center justify-center flex-shrink-0">
                  <MapPin className="w-5 h-5 text-olive" />
                </div>
                <div>
                  <h3 className="font-semibold text-foreground mb-1 text-sm">Lokasi</h3>
                  <p className="text-muted-foreground text-sm leading-relaxed">{RESTAURANT.address}</p>
                  <p className="text-olive text-sm font-medium mt-1.5">{RESTAURANT.shortAddress}</p>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-2xl p-6 border border-sand hover:border-olive/20 transition-all duration-300">
              <div className="flex items-start gap-4">
                <div className="w-11 h-11 bg-olive/10 rounded-xl flex items-center justify-center flex-shrink-0">
                  <Clock className="w-5 h-5 text-olive" />
                </div>
                <div>
                  <h3 className="font-semibold text-foreground mb-1 text-sm">Jam Operasional</h3>
                  <p className="text-muted-foreground text-sm">{RESTAURANT.hours}</p>
                  <p className="text-olive text-sm font-medium mt-1.5">Open Every Day</p>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-2xl p-6 border border-sand hover:border-olive/20 transition-all duration-300">
              <div className="flex items-start gap-4">
                <div className="w-11 h-11 bg-olive/10 rounded-xl flex items-center justify-center flex-shrink-0">
                  <Phone className="w-5 h-5 text-olive" />
                </div>
                <div>
                  <h3 className="font-semibold text-foreground mb-1 text-sm">Kontak</h3>
                  <a href={`tel:${RESTAURANT.phone}`} className="text-muted-foreground text-sm hover:text-olive transition-colors">
                    {RESTAURANT.phone}
                  </a>
                  <div className="flex gap-3 mt-3">
                    <a
                      href={`https://wa.me/${RESTAURANT.whatsapp}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1.5 bg-[#25D366]/10 text-[#25D366] px-3.5 py-2 rounded-full text-xs font-medium hover:bg-[#25D366]/20 transition-colors"
                    >
                      <MessageCircle className="w-3.5 h-3.5" /> WhatsApp
                    </a>
                    <a
                      href={RESTAURANT.instagramUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1.5 bg-pink-50 text-pink-600 px-3.5 py-2 rounded-full text-xs font-medium hover:bg-pink-100 transition-colors"
                    >
                      <Camera className="w-3.5 h-3.5" /> Instagram
                    </a>
                  </div>
                </div>
              </div>
            </div>

            <a
              href={RESTAURANT.mapsUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 bg-olive hover:bg-olive-dark text-white py-3.5 rounded-2xl font-semibold text-sm tracking-wide transition-all duration-300 hover:shadow-lg hover:shadow-olive/25"
            >
              <MapPin className="w-4 h-4" />
              Buka di Google Maps
            </a>
          </motion.div>

          {/* Map Embed */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="bg-white rounded-2xl overflow-hidden border border-sand h-[400px] lg:h-auto lg:min-h-[480px] shadow-sm"
          >
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3961.0!2d107.608!3d-6.913!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e68e7002faa85e7%3A0xbd9bb21cf8e9a378!2sBlue%20Olives%20Taverna!5e0!3m2!1sid!2sid!4v1"
              width="100%"
              height="100%"
              style={{ border: 0, minHeight: '400px' }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              title="Lokasi Blue Olives Taverna"
            />
          </motion.div>
        </div>
      </div>
    </section>
  )
}

// --- Footer ---
function Footer() {
  return (
    <footer className="bg-olive-dark text-white/70 relative overflow-hidden">
      {/* Decorative top wave */}
      <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-santorini via-gold to-olive-light" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-2.5 mb-4">
              <span className="text-2xl">🫒</span>
              <div>
                <span className="font-bold text-white text-lg block" style={{ fontFamily: 'var(--font-playfair), Georgia, serif' }}>
                  Blue Olives Taverna
                </span>
                <span className="text-white/40 text-[10px] tracking-[0.2em] uppercase">
                  A Santorini-Inspired Culinary Escape
                </span>
              </div>
            </div>
            <p className="text-white/50 text-sm leading-relaxed max-w-xs" style={{ fontFamily: 'var(--font-lato), sans-serif' }}>
              Where the Aegean breeze meets Bandung&apos;s highlands. An exquisite Mediterranean escape at Little MyKonos Hotel.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-white font-semibold text-sm mb-4 tracking-wide">Navigasi</h4>
            <div className="space-y-2.5">
              {[
                { label: 'Cerita Kami', href: '#about' },
                { label: 'Suasana', href: '#ambiance' },
                { label: 'Chef', href: '#chef' },
                { label: 'Acara', href: '#events' },
                { label: 'Reservasi', href: '#reservation' },
                { label: 'Kontak', href: '#contact' },
              ].map((link) => (
                <a
                  key={link.href}
                  href={link.href}
                  className="block text-white/50 text-sm hover:text-white transition-colors duration-300"
                >
                  {link.label}
                </a>
              ))}
            </div>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-white font-semibold text-sm mb-4 tracking-wide">Kontak</h4>
            <div className="space-y-3">
              <div className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-olive-light mt-0.5 flex-shrink-0" />
                <span className="text-white/50 text-sm">{RESTAURANT.shortAddress}</span>
              </div>
              <div className="flex items-center gap-2.5">
                <Clock className="w-4 h-4 text-olive-light flex-shrink-0" />
                <span className="text-white/50 text-sm">{RESTAURANT.hours}</span>
              </div>
              <div className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 text-olive-light flex-shrink-0" />
                <a href={`tel:${RESTAURANT.phone}`} className="text-white/50 text-sm hover:text-white transition-colors">
                  {RESTAURANT.phone}
                </a>
              </div>
              <div className="flex items-center gap-3 mt-3">
                <a
                  href={`https://wa.me/${RESTAURANT.whatsapp}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-9 h-9 bg-white/10 rounded-full flex items-center justify-center hover:bg-[#25D366]/30 transition-colors duration-300"
                  aria-label="WhatsApp"
                >
                  <MessageCircle className="w-4 h-4" />
                </a>
                <a
                  href={RESTAURANT.instagramUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-9 h-9 bg-white/10 rounded-full flex items-center justify-center hover:bg-pink-500/30 transition-colors duration-300"
                  aria-label="Instagram"
                >
                  <Camera className="w-4 h-4" />
                </a>
                <a
                  href={RESTAURANT.mapsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-9 h-9 bg-white/10 rounded-full flex items-center justify-center hover:bg-santorini/30 transition-colors duration-300"
                  aria-label="Google Maps"
                >
                  <MapPin className="w-4 h-4" />
                </a>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="mt-12 pt-6 border-t border-white/10 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-white/30 text-xs">
            &copy; {new Date().getFullYear()} Blue Olives Taverna. All rights reserved.
          </p>
          <p className="text-white/20 text-xs">
            Jl. Kebon Sirih No.31, Babakan Ciamis, Bandung 40117
          </p>
        </div>
      </div>
    </footer>
  )
}

// --- Scroll to Top Button ---
function ScrollToTop() {
  const [visible, setVisible] = useState(false)

  useEffect(() => {
    const onScroll = () => setVisible(window.scrollY > 600)
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  return (
    <AnimatePresence>
      {visible && (
        <motion.button
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.8 }}
          onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
          className="fixed bottom-6 right-6 z-40 w-12 h-12 bg-olive hover:bg-olive-dark text-white rounded-full shadow-lg shadow-olive/20 flex items-center justify-center transition-all duration-300 hover:shadow-xl hover:-translate-y-0.5"
          aria-label="Kembali ke atas"
        >
          <ChevronDown className="w-5 h-5 rotate-180" />
        </motion.button>
      )}
    </AnimatePresence>
  )
}

/* ============================================================
   MAIN PAGE COMPONENT
   ============================================================ */

export default function BlueOlivesTaverna() {
  return (
    <main>
      <Navbar />
      <HeroSection />
      <AboutSection />
      <AmbianceSection />
      <ChefSection />
      <EventsSection />
      <TestimonialsSection />
      <ReservationSection />
      <ContactSection />
      <Footer />
      <ScrollToTop />
    </main>
  )
}
