============================================================
  🫒 BLUE OLIVES TAVERNA — SOURCE CODE WEBSITE
============================================================

CARA MENJALANKAN PROYEK INI:

1. Install Node.js (versi 18+) dan bun/npm
2. Ekstrak file zip ini
3. Buka terminal di folder hasil ekstrak
4. Jalankan perintah:
     npm install
     npm run dev
5. Buka browser di: http://localhost:3000

STRUKTUR FILE PENTING:
- src/app/layout.tsx   → Root layout & font (Playfair + Lato)
- src/app/globals.css  → Palet warna Mediterania & animasi
- src/app/page.tsx     → SELURUH konten website (10 section)
- public/images/venue/ → Gambar restoran (eksterior, interior, ambience)

GANTI GAMBAR:
- Simpan gambar baru di folder: public/images/venue/
- Ubah path di dalam file page.tsx (bagian GALLERY_ITEMS)

DEPLOY KE INTERNET:
- Vercel: https://vercel.com (paling mudah, gratis)
- Netlify: https://netlify.com
- Atau hosting VPS dengan Node.js

============================================================
  Dibuat dengan Next.js 16 + Tailwind CSS 4 + Framer Motion
============================================================
